from pipfilemerge import tomlHandler

update = tomlHandler.updatePipfile
