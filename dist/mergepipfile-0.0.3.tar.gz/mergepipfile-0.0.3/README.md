Merge Pipfile
==============

Merges the Pipfiles in the current directory with any other Pipfiles in sub-directories.

Used as a tool to allow for unpublished custom libraries to be included in your virtual environment made by Pipfile
